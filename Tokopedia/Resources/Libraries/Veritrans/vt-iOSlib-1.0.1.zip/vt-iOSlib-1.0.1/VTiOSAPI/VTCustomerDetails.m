//
//  VTCustomerDetails.m
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/11/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//


#import "VTCustomerDetails.h"

@implementation VTCustomerDetails

@synthesize first_name = _first_name;
@synthesize last_name = _last_name;
@synthesize email = _email;
@synthesize phone = _phone;

@end