//
//  VTiOSAPI.m
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/10/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//

#import "VTiOSAPI.h"

@implementation VTiOSAPI

@end
