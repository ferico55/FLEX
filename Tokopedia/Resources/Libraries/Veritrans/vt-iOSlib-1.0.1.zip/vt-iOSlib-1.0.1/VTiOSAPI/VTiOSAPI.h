//
//  VTiOSAPI.h
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/10/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VTiOSAPI : NSObject

@end
