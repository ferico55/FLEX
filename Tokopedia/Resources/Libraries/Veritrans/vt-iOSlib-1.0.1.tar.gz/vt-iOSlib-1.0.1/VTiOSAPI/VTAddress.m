//
//  VTAddress.m
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/11/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//


#import "VTAddress.h"

@implementation VTAddress


@synthesize first_name;
@synthesize last_name;
@synthesize address;
@synthesize city;
@synthesize postal_code;
@synthesize phone;
@synthesize country_code;


@end
