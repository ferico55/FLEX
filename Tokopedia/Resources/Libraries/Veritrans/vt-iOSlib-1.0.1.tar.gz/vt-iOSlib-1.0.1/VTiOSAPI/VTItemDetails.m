//
//  VTItemDetails.m
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/11/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//


#import "VTItemDetails.h"

@implementation VTItemDetails

@synthesize itemId = _itemId;
@synthesize price = _price;
@synthesize quantity = _quantity;
@synthesize name = _name;

@end