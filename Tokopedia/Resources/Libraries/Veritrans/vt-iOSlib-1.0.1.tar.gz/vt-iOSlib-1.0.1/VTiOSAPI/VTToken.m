//
//  VTToken.m
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/11/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//

#import "VTToken.h"

@implementation VTToken

@synthesize status_code = _status_code;
@synthesize status_message = _status_message;
@synthesize redirect_url = _redirect_url;
@synthesize token_id = _token_id;
@synthesize bank = _bank;

@end
