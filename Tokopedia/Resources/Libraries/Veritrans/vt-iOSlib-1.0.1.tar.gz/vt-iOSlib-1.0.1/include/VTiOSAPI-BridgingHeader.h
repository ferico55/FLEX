//
//  VTiOSAPI-BridgingHeader.h
//  VTiOSAPI
//
//  Created by Muhammad Anis on 12/11/14.
//  Copyright (c) 2014 Veritrans Indonesia. All rights reserved.
//

#ifndef __VTiOS_API_BRIDGING_HEADER_H__
#define __VTiOS_API_BRIDGING_HEADER_H__

#import "VTDirect.h"
#import "VTConfig.h"

#endif
